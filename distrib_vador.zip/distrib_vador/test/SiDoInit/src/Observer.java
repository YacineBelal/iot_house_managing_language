

import java.awt.Color;

public interface Observer {
	public void update(String str);	
	public void update(Color color);
}
