

	// a subdiviser en fct de l'appareil !!

	public enum TypeActionAppareil {
			 ALLUMER, ETEINDRE, TAMISER,
			 ALLUMER_PARTIEL, ALLUMER_ECO,
			 OUVRIR, FERMER, OUVRIR_PARTIEL, FERMER_PARTIEL
			}
	